Setup
=====

# Initializing files
Place everything (except this file) to your website root directory.  
For XAMPP, it's usually at `<XAMPP install directory>/htdocs`.  
For Laragon, it's usually at `<Laragon install directory>/www`.
For Linux, it's usually at `\etc\var\www`.

# Database
Open `localhost/reset.html` and press `Yes` to initialize database.


Testing
=======

Open `localhost` to open the main database control page.
Optionally, open `localhost/index.php?page=1` to open the 1st database page.